package com.springexample;

public interface Car {
          public  void printCarName();
}
