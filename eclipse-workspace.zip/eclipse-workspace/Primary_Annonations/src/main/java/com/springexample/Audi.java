package com.springexample;

import org.springframework.stereotype.Component;



@Component

public class Audi implements Car{

 

	  public void printCarName() {
	    System.out.println("Audi");
	  }

}