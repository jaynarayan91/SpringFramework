package com.springexample;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;


@Component
@Primary
public class Honda implements Car{

 

	
	  public void printCarName() {
	    System.out.println("Honda is my car!!!");
	  }

}