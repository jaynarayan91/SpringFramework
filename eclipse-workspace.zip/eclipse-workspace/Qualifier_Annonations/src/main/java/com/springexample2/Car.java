package com.springexample2;

public interface Car {
	public void printCarName();

}
