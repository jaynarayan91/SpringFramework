package com.springexample2;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

 

@Component
@Qualifier("Mahindra")

public class Mahindra implements Car{
        public void printCarName() {

                System.out.println("Mahindra is a old car");

        }

}