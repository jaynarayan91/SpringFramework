/*
 * package com.springboot.example;
 * 
 * public class StudentBean { private int rollno; private String Name; private
 * float mark;
 * 
 * public int getRollno() { return rollno; }
 * 
 * public void setRollno(int rollno) { this.rollno = rollno; }
 * 
 * public String getName() { return Name; }
 * 
 * public void setName(String name) { Name = name; }
 * 
 * public float getMark() { return mark; }
 * 
 * public void setMark(float mark) { this.mark = mark; }
 * 
 * 
 * 
 * }
 */