package com.HttpSession.servlet;

import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;  
  
  
public class FirstServlet extends HttpServlet {  
  
public void doPost(HttpServletRequest request, HttpServletResponse response){  
        try{  
  
        response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  
          
        String name = request.getParameter("name");
		out.println("<h1> Hello, Welcome to the portal,  " + name
					+ " </h1>");
          
        HttpSession session=request.getSession();  
        session.setAttribute("user_name", name);  
  
        out.print("<a href='SecondServlet'>visit</a>");  
                  
        out.close();  
  
                }
        catch(Exception e){
        	System.out.println(e);}  
        }
}
    