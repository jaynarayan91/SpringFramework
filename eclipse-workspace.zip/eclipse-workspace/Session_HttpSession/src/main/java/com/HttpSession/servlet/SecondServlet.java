package com.HttpSession.servlet;

import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;  
  
public class SecondServlet extends HttpServlet {  
  
public void doGet(HttpServletRequest request, HttpServletResponse response)  {
        try{  
  
        response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  
          
        HttpSession session=request.getSession(false);  
        String name=(String)session.getAttribute("user_name");  
        out.println("<h1> Hello, welcome back "
				+ name + " </h1>");
	out.println("<h2>Thank you!!</h2>"); 
  
        out.close();  
  
                }
catch(Exception e){System.out.println(e);}   
    } 
}