package com.firstprogram.spring;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        College obj = new Student();
        obj.display();
    }
}
