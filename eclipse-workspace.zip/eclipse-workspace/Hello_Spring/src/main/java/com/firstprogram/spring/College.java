package com.firstprogram.spring;

public interface College {
	void display();
		
	}


