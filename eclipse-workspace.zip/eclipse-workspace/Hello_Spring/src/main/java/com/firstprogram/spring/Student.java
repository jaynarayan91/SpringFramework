package com.firstprogram.spring;

public class Student implements College{
	public void display() {
		System.out.println("I am a student");
	}

}
