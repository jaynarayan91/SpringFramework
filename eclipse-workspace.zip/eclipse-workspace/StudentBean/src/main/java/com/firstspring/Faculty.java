package com.firstspring;


import org.springframework.stereotype.Component;

@Component
public class Faculty implements College {
	public void Display() {
		System.out.println("I am Faculty");
	}
}