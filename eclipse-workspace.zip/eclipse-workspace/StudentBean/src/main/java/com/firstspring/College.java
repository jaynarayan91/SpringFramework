package com.firstspring;


public interface College {
	public void Display() ;
}