package com.firstspring;


import org.springframework.stereotype.Component;

@Component
public class Student implements College {
	public void Display() {
		System.out.println("I am Student");
	}
}
