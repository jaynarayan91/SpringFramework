package com.mvc.bean;

public class LoginBean
{
	 private String UserName;
	 private String password;

	public String getUserName() {
		return UserName;
	 }
	public void setUserName(String userName) {
		this.UserName = userName;
	 }
	 public String getPassword() {
		return password;
	 }
	 public void setPassword(String password) {
		this.password = password;
	 }
}