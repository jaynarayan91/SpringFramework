package com.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class Addition {
@RequestMapping("/calculator")
public ModelAndView findsum(HttpServletRequest request, HttpServletRequest response) {
	int x = Integer.parseInt(request.getParameter("no1"));
	int y = Integer.parseInt(request.getParameter("no2"));
	int r = x+y;
	ModelAndView mView = new ModelAndView();
	mView.setViewName("result");
	mView.addObject("res",r);
	return mView;
}

}